<?php $__env->startSection('title', 'Show Course | '); ?>

<?php
    $fields = [
        'title',
        'description',
        'duration',
        'instructor',
        'fees',
        'discounted_fees',
        'category_id',
        'course_image',
    ];
    $countCompletedFields = 0;
    foreach ($fields as $field) {
        if ($course->$field) {
            $countCompletedFields++;
        }
    }
    $countCompletedFields += $course->chapters->isNotEmpty() ? 1 : 0;
    $countCompletedFields += $course->features->count() ? 1 : 0;
    $countCompletedFields += $course->batches->count() ? 1 : 0;
    $totalFields = count($fields) + 3; // Add 2 if chapters and features exist
?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="mb-4 p-4 mt-5 bg-green-100 text-green-800 rounded-md">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="flex px-[2%] py-0 flex-col">
        <div class="flex gap-3 my-5 flex-row justify-between items-center">
            <div class="flex flex-1 flex-col border-s-4 border-s-orange-400 pl-3">
                <h2 class="md:text-xl text-lg font-normal dark:text-slate-300 text-slate-500">View Course</h2>
                <p class="text-sm text-slate-400 font-normal">Please fill <?php echo e($countCompletedFields); ?> of <?php echo e($totalFields); ?>

                    fields</p>
            </div>

            <div class="inline-flex flex-row md:items-center gap-2" role="group">
                <form action="<?php echo e(route($course->published ? 'course.unpublish' : 'course.publish', $course->id)); ?>"
                    method="POST" class="inline-flex" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="px-3 py-2 <?php echo e($course->published ? 'bg-white hover:bg-teal-600 border border-teal-600 hover:text-white text-teal-600' : 'bg-teal-600 text-white'); ?>  rounded-lg <?php echo e($countCompletedFields == $totalFields ? 'opacity-100' : 'opacity-50 cursor-not-allowed'); ?>"
                        <?php echo e($countCompletedFields != $totalFields && !$course->published ? 'disabled' : ''); ?>>
                        <?php echo e($course->published ? 'Unpublish Course' : 'Publish Course'); ?>

                    </button>
                </form>
            </div>
        </div>

        <div class="flex  flex-1  md:flex-row flex-col md:items-start gap-5">

            <div class="flex flex-1 gap-5 flex-col">

                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-1 bg-slate-100 p-3 rounded border">
                        <div class="flex flex-1 flex-col gap-2">
                            <div class="flex flex-1 justify-between">
                                <strong class="text-lg font-normal text-slate-600"><?php echo e(ucfirst($field)); ?></strong>
                                <button onclick="toggleEdit('<?php echo e($field); ?>')"
                                    class="bg-teal-600 text-white text-sm px-3 py-1 self-start rounded">Edit</button>
                            </div>

                            <span id="<?php echo e($field); ?>-value">
                                <?php if($course->$field): ?>
                                    <?php echo $field == 'fees' || $field == 'discounted_fees'
                                        ? '₹ ' . number_format($course->$field, 2)
                                        : ($field == 'duration'
                                            ? $course->$field . ' Weeks'
                                            : ($field == 'category_id'
                                                ? $course->category->cat_title
                                                : ($field == 'course_image'
                                                    ? "<img src='" .
                                                        ($course->$field
                                                            ? asset('storage/course_images/' . $course->$field)
                                                            : 'https://placehold.co/600x400?text=Upload+Image') .
                                                        "' alt='Image Preview' class='w-full h-auto object-cover border'>"
                                                    : e($course->$field)))); ?>

                                <?php else: ?>
                                    <span class="italic"><?php echo e($field); ?> is empty</span>
                                <?php endif; ?>
                            </span>
                            <form id="<?php echo e($field); ?>-form"
                                action="<?php echo e(route('course.update', ['course' => $course->id, 'field' => $field])); ?>"
                                method="POST" enctype="multipart/form-data" style="display: none;"
                                class="flex flex-col w-full">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="mb-3 flex flex-1 flex-col gap-1">
                                    <?php if($field == 'description'): ?>
                                        <textarea name="<?php echo e($field); ?>" class="border w-full px-3 py-2" rows="5"><?php echo e($course->$field); ?></textarea>
                                    <?php elseif($field == 'course_image'): ?>
                                        <input type="file" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>"
                                            onchange="previewImage(event)">
                                        <div class="mt-2">
                                            <img id="<?php echo e($field); ?>-preview"
                                                src="<?php echo e($course->$field ? asset('storage/course_images/' . $course->$field) : 'https://placehold.co/600x400?text=Upload+Image'); ?>"
                                                alt="Image Preview" class="w-56 h-32 object-cover border">
                                        </div>
                                    <?php elseif($field == 'category_id'): ?>
                                        <select name="<?php echo e($field); ?>" class="px-3 py-2 w-full">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"
                                                    <?php echo e($category->id == $course->category_id ? 'selected' : ''); ?>>
                                                    <?php echo e($category->cat_title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php else: ?>
                                        <input class="border w-full px-3 py-2"
                                            type="<?php echo e($field == 'fees' || $field == 'discounted_fees' || $field == 'duration' ? 'number' : 'text'); ?>"
                                            name="<?php echo e($field); ?>" value="<?php echo e($course->$field); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="flex gap-2">
                                    <button type="submit" class="bg-black text-white px-3 py-2 rounded">Save</button>
                                    <button type="button" onclick="toggleEdit('<?php echo e($field); ?>')"
                                        class="bg-gray-500 text-white px-3 py-2 rounded">Cancel</button>
                                </div>
                            </form>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            

            

            <div class="flex flex-1 flex-col  gap-5">
                <div class="flex flex-1 bg-slate-100 p-3 rounded border">
                    <div class="flex flex-1 flex-col gap-2">
                        <strong class="text-lg font-normal text-slate-600">Course Status</strong>
                        <span id="course-status">
                            <?php if($course->published): ?>
                                <span class="text-green-500">Published</span>
                            <?php else: ?>
                                <span class="text-red-500">Not Published</span>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>


                <div class="flex flex-1 bg-slate-100 flex-col p-3 rounded border">
                    <div class="flex flex-1 justify-between mb-2 ">
                        <strong class="text-lg font-normal text-slate-600">Chapters</strong>
                        <button onclick="toggleAddChapterForm()"
                            class="bg-teal-600 text-white text-sm px-3 py-1 self-start rounded">Add Chapter</button>
                    </div>

                    <?php if($course->chapters->isEmpty()): ?>
                        <span class="italic">No chapters available</span>
                    <?php else: ?>
                        <?php $__currentLoopData = $course->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-white p-3 mb-3 rounded border">
                                <div class="flex justify-between">
                                    <strong class="text-md font-normal text-slate-600">Chapter:
                                        <?php echo e($chapter->title); ?></strong>
                                    <div class="flex gap-2">
                                        <a href="<?php echo e(route('lessons.create', $chapter->id)); ?>"
                                            class="bg-teal-600 text-white text-sm px-3 py-1 rounded">Add Lesson</a>
                                        <a href="<?php echo e(route('chapter.edit', $chapter->id)); ?>"
                                            class="bg-blue-600 text-white text-sm px-3 py-1 rounded">Edit Chapter</a>
                                        <form action="<?php echo e(route('chapter.destroy', $chapter->id)); ?>" method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this chapter?');"
                                            class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="bg-red-600 text-white text-sm px-3 py-1 rounded">Delete</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="ml-4">
                                    <?php if($chapter->lessons && !$chapter->lessons->isEmpty()): ?>
                                        <ul class="list-disc ml-5">
                                            <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($lesson->title); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <span class="italic">No lessons available for this chapter</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <div class="flex flex-1  bg-lime-100 px-2 rounded border">
                        <div class="flex flex-1 flex-col gap-2">
                            <form id="add-chapter-form" action="<?php echo e(route('chapter.store', $course->id)); ?>" method="POST"
                                class="flex gap-2 py-2" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                                <div class="mb-3">
                                    <label for="title" class="block text-sm font-medium text-slate-600">Chapter
                                        Title</label>
                                    <input type="text" name="title" id="title" class="border w-full px-3 py-2"
                                        required>
                                </div>
                                <button type="submit" class="bg-teal-600 text-white px-3 py-2 rounded">Add</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="flex flex-1 flex-col bg-slate-100 p-3">
                    <div class="flex flex-1 justify-between mb-2">
                        <strong class="text-lg font-normal text-slate-600">Features</strong>
                        <button onclick="toggleAddFeatureForm()"
                            class="bg-teal-600 text-white text-sm px-3 py-1 self-start rounded">Add Feature</button>
                    </div>

                    <?php if($course->features->isEmpty()): ?>
                        <span class="italic">No features available</span>
                    <?php else: ?>
                        <ul class="list-disc ml-5">
                            <?php $__currentLoopData = $course->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($feature->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                    <div class="flex flex-1 bg-lime-100 px-2 rounded border">
                        <div class="flex flex-1 flex-col gap-2">
                            <form id="add-feature-form" action="<?php echo e(route('course.addFeature', $course->id)); ?>"
                                method="POST" class="flex flex-col gap-2 py-2" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="features" class="block text-sm font-medium text-slate-600">Select
                                        Features</label>
                                    <select name="features[]" id="features" class="border w-full px-3 py-2" multiple>
                                        <?php $__currentLoopData = $allFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($feature->id); ?>"><?php echo e($feature->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <button type="submit" class="bg-teal-600 text-white px-3 py-2 rounded self-end">Add
                                    Features</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="flex flex-1 flex-col bg-slate-100 p-3">
                    <div class="flex flex-1 justify-between mb-2">
                        <strong class="text-lg font-normal text-slate-600">Batches</strong>
                        <button onclick="toggleAddBatchForm()"
                            class="bg-teal-600 text-white text-sm px-3 py-1 self-start rounded">Add Batch</button>
                    </div>

                    <?php if($course->batches->isEmpty()): ?>
                        <span class="italic">No batches available</span>
                    <?php else: ?>
                        <ul class="space-y-2">
                            <?php $__currentLoopData = $course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li
                                    class="flex items-center justify-between p-3 bg-white rounded shadow border border-gray-200">
                                    <div class="flex flex-col">
                                        <span class="font-semibold text-gray-800"><?php echo e($batch->batch_name); ?></span>
                                        <span class="text-sm text-gray-600">
                                            <?php echo e(\Carbon\Carbon::parse($batch->start_date)->format('d M, Y')); ?> to
                                            <?php echo e(\Carbon\Carbon::parse($batch->end_date)->format('d M, Y')); ?>

                                        </span>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo e($batch->available_seats); ?>/<?php echo e($batch->total_seats); ?> Seats
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                    <div id="addBatchForm" class="flex flex-1 mt-2 bg-lime-100 p-2 rounded border hidden">
                        <div class="flex flex-1 flex-col gap-2">
                            <form action="<?php echo e(route('batches.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">

                                <!-- Batch Name -->
                                <div class="mb-4">
                                    <label for="batch_name" class="block text-gray-700 font-bold mb-2">Batch Name</label>
                                    <input type="text" name="batch_name" id="batch_name"
                                        class="form-input block w-full mt-1" value="<?php echo e(old('batch_name')); ?>" required>
                                    <?php $__errorArgs = ['batch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Start Date -->
                                <?php
                                    $today = date('Y-m-d');
                                ?>

                                <div class="flex flex-1 gap-3">
                                    <!-- Start Date -->
                                    <div class="mb-4 flex-1">
                                        <label for="start_date" class="block text-gray-700 font-bold mb-2">Start
                                            Date</label>
                                        <input type="date" name="start_date" id="start_date"
                                            class="form-input block w-full mt-1" value="<?php echo e(old('start_date')); ?>"
                                            min="<?php echo e($today); ?>" required>
                                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- End Date -->
                                    <div class="mb-4 flex-1">
                                        <label for="end_date" class="block text-gray-700 font-bold mb-2">End Date</label>
                                        <input type="date" name="end_date" id="end_date"
                                            class="form-input block w-full mt-1" value="<?php echo e(old('end_date')); ?>" required>
                                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="flex flex-1 gap-3">

                                    <!-- Total Seats -->
                                    <div class="mb-4 flex-1">
                                        <label for="total_seats" class="block text-gray-700 font-bold mb-2">Total
                                            Seats</label>
                                        <input type="number" name="total_seats" id="total_seats"
                                            class="form-input block w-full mt-1" value="<?php echo e(old('total_seats')); ?>"
                                            required>
                                        <?php $__errorArgs = ['total_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Available Seats -->
                                    <div class="mb-4 flex-1">
                                        <label for="available_seats" class="block text-gray-700 font-bold mb-2">Available
                                            Seats</label>
                                        <input type="number" name="available_seats" id="available_seats"
                                            class="form-input block w-full mt-1" value="<?php echo e(old('available_seats')); ?>"
                                            required>
                                        <?php $__errorArgs = ['available_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="mb-4">
                                    <button type="submit" class="bg-blue-500 text-white font-bold py-2 px-4 rounded">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


            </div>


        </div>
    </div>

    <script>
   document.getElementById('start_date').addEventListener('change', function() {
        let startDate = new Date(this.value);
        let endDate = new Date(startDate);
        let courseDuration = <?php echo e($course->duration); ?>; // Get the course duration in days

        endDate.setDate(endDate.getDate() + courseDuration * 7); // Adds the course duration to the start date

        let formattedEndDate = endDate.toISOString().split('T')[0];
        document.getElementById('end_date').value = formattedEndDate;
    });

        function toggleEdit(field) {
            const valueSpan = document.getElementById(field + '-value');
            const form = document.getElementById(field + '-form');
            const isFormVisible = form.style.display === 'block';

            if (isFormVisible) {
                valueSpan.style.display = 'block';
                form.style.display = 'none';
            } else {
                valueSpan.style.display = 'none';
                form.style.display = 'block';
            }
        }

        function previewImage(event) {
            const reader = new FileReader();
            reader.onload = function() {
                const output = document.getElementById(event.target.id + '-preview');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }

        function toggleAddChapterForm() {
            const form = document.getElementById('add-chapter-form');
            const isFormVisible = form.style.display === 'block';

            if (isFormVisible) {
                form.style.display = 'none';
            } else {
                form.style.display = 'block';
            }
        }

        function toggleAddFeatureForm() {
            const form = document.getElementById('add-feature-form');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }

        function toggleAddBatchForm() {
            const form = document.getElementById('addBatchForm');
            form.classList.toggle('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codewith/public_html/resources/views/admin/viewCourse.blade.php ENDPATH**/ ?>