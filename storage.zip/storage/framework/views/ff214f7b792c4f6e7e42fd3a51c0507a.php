<?php $__env->startSection('title', 'Insert Course | '); ?>


<?php $__env->startSection('content'); ?> 
        <div class="flex gap-3   mt-5  px-[2%] flex-row justify-between items-center">

            <h2 class="md:text-xl text-lg font-semibold dark:text-slate-300 text-slate-500 border-s-4 border-s-orange-400 pl-3">
                Insert Course</h2>

            <div class="inline-flex flex-row  md:items-center gap-2" role="group">
                
                <a href="<?php echo e(route('course.index')); ?>"
                    class="px-3 py-2 bg-teal-600 rounded-lg text-white self-start">
                    View All Courses
                </a>
            </div>

        </div>
        <div class="flex flex-1 flex-col px-[2%] w-full justify-center items-center">
            <?php if (isset($component)) { $__componentOriginalad73930ab0833c057efad93d32544ba1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad73930ab0833c057efad93d32544ba1 = $attributes; } ?>
<?php $component = App\View\Components\InsertCourse::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('insert-course'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InsertCourse::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad73930ab0833c057efad93d32544ba1)): ?>
<?php $attributes = $__attributesOriginalad73930ab0833c057efad93d32544ba1; ?>
<?php unset($__attributesOriginalad73930ab0833c057efad93d32544ba1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad73930ab0833c057efad93d32544ba1)): ?>
<?php $component = $__componentOriginalad73930ab0833c057efad93d32544ba1; ?>
<?php unset($__componentOriginalad73930ab0833c057efad93d32544ba1); ?>
<?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codewith/public_html/resources/views/admin/insertCourse.blade.php ENDPATH**/ ?>