<?php $__env->startSection('title', 'Add Lesson'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex px-[2%] py-0 flex-col">
        <div class="flex gap-3 my-5 flex-row justify-between items-center">
            <div class="flex flex-1 flex-col border-s-4 border-s-orange-400 pl-3">
                <h2 class="md:text-xl text-lg font-normal dark:text-slate-300 text-slate-500 ">
                    Add New Lesson to Chapter: <?php echo e($chapter->title); ?></h2>
            </div>
            <div class="inline-flex flex-row md:items-center gap-2" role="group">
                <a href="<?php echo e(route('course.show', $chapter->course_id)); ?>"
                    class="px-3 py-2 bg-teal-600 rounded-lg text-white self-start">
                    Back to Course
                </a>
            </div>
        </div>

        <div class="bg-white p-5 rounded shadow">
            <form action="<?php echo e(route('lessons.store', $chapter->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="mb-4">
                    <label for="title" class="block text-gray-700">Lesson Title:</label>
                    <input type="text" id="title" name="title" value="<?php echo e(old('title')); ?>"
                           class="border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                
                <div class="flex gap-4">
                    <button type="submit" class="bg-teal-600 text-white px-3 py-2 rounded">Save Lesson</button>
                    <a href="<?php echo e(route('course.show', $chapter->course_id)); ?>" class="bg-gray-500 text-white px-3 py-2 rounded">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codewith/public_html/resources/views/admin/lessons/create.blade.php ENDPATH**/ ?>