<?php $__env->startSection('title', 'Manage Categories |'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-1 flex-col">
        <div class="md:px-[10%] px-5 py-5">
            <div class="flex gap-3 flex-col md:flex-row justify-between md:items-center">

                <h2 class="md:text-xl text-lg font-semibold dark:text-slate-300 text-slate-500 border-s-4 border-s-orange-400 pl-3"><?php if(isset($_GET['search']) && $_GET['search'] !== ""): ?>
                    <?php echo e($_GET['search']); ?>

                <?php else: ?> 
                    <?php echo e("Manage all"); ?>

                <?php endif; ?> Categories (<?php echo e(count($categories)); ?>)</h2>

            </div>
            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="p-4 my-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
                <span class="font-medium">Success!</span> <?php echo e(session('success')); ?>

              </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
            
            <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="p-4 my-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
                <span class="font-medium">Success!</span> <?php echo e(session('error')); ?>

              </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
            <div class="flex flex-1 gap-3  mt-5">
                <div class="w-9/12">
                    <div class="relative overflow-x-auto flex-1 border dark:border-slate-500">
                        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" class="px-6 py-3">
                                        Id
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Title
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        slug
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Description
                                    </th>
                                   
                                    <th scope="col" class="px-6 py-3">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                        <th scope="row"
                                            class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                            <?php echo e($category->id); ?>

                                        </th>
                                        <td class="px-6 py-4">
                                            <?php echo e($category->cat_title); ?>

                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($category->cat_slug); ?>

                                        </td>
                                       
                                        
                                        <td class="px-6 py-4">
                                            <?php echo e($category->cat_description); ?>

                                        </td>
                                        <td class="flex gap-2 items-center px-6 py-4">
                                           
                                            <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="POST"
                                                class="inline-flex items-center">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" name="delete"
                                                    class="px-3 py-2 text-sm font-medium text-white bg-red-500" value="X">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                            </tbody>
                        </table>

                       
                    </div>
                    <div class="flex flex-1 space-x-2 justify-center mt-2 pagination">
                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
                <div class="w-3/12">
                    <div class="bg-slate-100 rounded p-3">
                        <form action="<?php echo e(route('category.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3 flex flex-col gap-2">
                                <label for="" class="">Category title</label>
                                <input type="text" name="cat_title" value="<?php echo e(old('cat_title')); ?>" class="border w-full px-3 py-2 rounded">
                                <?php $__errorArgs = ['cat_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-xs text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 flex flex-col gap-2">
                                <label for="" class="">Category description</label>
                                <textarea rows="5" name="cat_description" value="<?php echo e(old('cat_description')); ?>" class="border w-full px-3 py-2 rounded"></textarea>
                                <?php $__errorArgs = ['cat_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-xs text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <input type="submit" class="bg-emerald-600 px-3 py-2 text-2xl text-center text-white rounded w-full" value="Create Category">
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codewith/public_html/resources/views/admin/manageCategory.blade.php ENDPATH**/ ?>